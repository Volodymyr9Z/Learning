USE Contacts;

EXEC dbo.SelectContact @ContactId = 21;