Welcome to Programming SQL Server Database Stored Procedures!
I hope you are enjoying/have enjoyed the course.
To set up the database:

1. Copy the folder to your system.
2. Open up the script 00 Apply.sql.
3. The second line in the script is:

:setvar path "C:\temp\contactsdb\"

Change C:\temp\contactsdb\ to the required path. 
Ensure the value remains wrapped in quotes and finishes with a slash \.

4. Save the script.
5. Open up 00 Apply.sql in SQL Server Management Studio.
6. In the Query menu, select SQLCMD Mode.
7. Hit F5 to create the database!